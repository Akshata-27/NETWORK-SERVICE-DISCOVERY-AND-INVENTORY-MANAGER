# Network Service Discovery and Inventory Manager

A small Python learning project that checks a chosen set of TCP ports on IP addresses you explicitly provide, saves the results to JSON, and compares each scan with the prior saved snapshot.

## Use safely

Run this only against systems you own or are authorized to assess. The program does not expand CIDR ranges or discover hosts automatically. You must supply each IPv4 or IPv6 address. It checks only the selected ports; the default is five ports, and each connection has a short timeout. A result marked open means a TCP connection succeeded at scan time. A failed connection can mean closed, filtered, or unreachable; this tool does not determine which.

## Requirements and setup

Python 3.10 or newer; no third-party packages are required. From the `outputs` folder, create and activate a virtual environment if desired, then run:

```text
python -m network_service_inventory --help
```

## Run a scan

Supply an explicitly authorized IP address and optionally a custom small port list:

```text
python -m network_service_inventory 192.0.2.10 --ports 22,80,443 --timeout 0.5 --inventory inventory.json
```

`192.0.2.10` is reserved for documentation and is only an example. Replace it with an address you are authorized to check. To check a second specific IP, add it as another argument. The tool rejects hostnames, malformed addresses, and CIDR ranges. Port numbers must be from 1 through 65535. Timeouts are limited to at most 10 seconds.

The first scan creates the inventory file. Later scans read it as the previous baseline, report newly detected and disappeared host/port pairs, then replace it with the current snapshot. Keep a copy of the JSON file if you need a longer history.

## Run the local tests

From the `outputs` folder, run the tests. They bind a temporary TCP server on loopback (`127.0.0.1`) and never contact external hosts:

```text
python -m unittest discover -s network_service_inventory/tests -v
```

## Project structure

- `__main__.py` — command-line options, address validation, scan orchestration, and readable results.
- `scanner.py` — uses `socket` TCP connections with a timeout; records only successful connections.
- `inventory.py` — reads/writes JSON and compares service sets between scans.
- `tests/test_inventory.py` — checks comparison, JSON storage, invalid input, and a local mock server.

## Concepts used

| Concept | Where it appears | Classification |
| --- | --- | --- |
| Variables, lists, dictionaries, strings, integers | Scan inputs and inventory data | Python basics / syllabus |
| Conditions and loops | Validate options; iterate over hosts and ports | Python basics / syllabus |
| Functions and modules | Scanner, inventory helpers, CLI entry point | Python basics / syllabus |
| Exceptions | Invalid addresses, file errors, failed connections | Python basics / syllabus |
| File handling | Persist and reload JSON inventory | Python basics / syllabus |
| Standard libraries (`socket`, `json`, `argparse`, `ipaddress`, `datetime`, `pathlib`) | Networking, CLI, validation, timestamps, storage | Python standard library / syllabus-aligned |
| TCP connect checks and timeouts | Bounded port reachability checks | Socket programming / syllabus concept |
| Snapshot comparison | Identify newly seen or missing services | Automation / project logic |
| `unittest`, ephemeral local server, threads | Local verification | Standard library; testing/concurrency may be new concepts |
| JSON format and command-line flags | Structured storage and user interface | Standard-library features; possibly new concepts |

The uploaded module PDF was not present in this development workspace, so the classifications above use the syllabus topics listed in the project request. Match these labels to the exact chapters in your PDF when you have it available.

