"""Network Service Discovery and Inventory Manager.

Only scans IP addresses explicitly supplied by the operator. Use only on systems
and networks for which you have permission.
"""
