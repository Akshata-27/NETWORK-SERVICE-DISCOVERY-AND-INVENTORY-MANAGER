"""Command-line entry point for the inventory manager."""

import argparse #Loads Python’s command-line argument tool. It helps the program accept options such as --ports and --timeout
import ipaddress
import sys
from pathlib import Path

from .inventory import compare_inventories, load_inventory, save_inventory
from .scanner import DEFAULT_PORTS, scan_hosts


def parse_ports(value: str) -> list[int]:
    """Parse a comma-separated list of TCP ports and validate its range."""
    try:
        ports = [int(part.strip()) for part in value.split(",") if part.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("ports must be comma-separated numbers") from exc
    if not ports or any(port < 1 or port > 65535 for port in ports):
        raise argparse.ArgumentTypeError("provide one or more ports from 1 to 65535")
    return list(dict.fromkeys(ports))


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Check a small list of TCP ports on explicitly named, authorized IPs."
    )
    parser.add_argument("hosts", nargs="+", help="explicit IP address(es); hostnames are not accepted")
    parser.add_argument("--ports", type=parse_ports, default=DEFAULT_PORTS,
                        help=f"comma-separated TCP ports (default: {','.join(map(str, DEFAULT_PORTS))})")
    parser.add_argument("--timeout", type=float, default=0.5, help="connection timeout in seconds (default: 0.5)")
#means each connection attempt waits up to half a second unless the user chooses another value.
    parser.add_argument("--inventory", type=Path, default=Path("inventory.json"), help="JSON inventory output path")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv) #Reads the user’s command-line inputs and stores them in args
    if args.timeout <= 0 or args.timeout > 10: #Checks that the timeout is greater than zero and no more than ten seconds.
        print("Error: timeout must be greater than 0 and at most 10 seconds.", file=sys.stderr)
        return 2
    try:
        # Parse first to reject hostnames and malformed addresses before any network activity.
        hosts = [str(ipaddress.ip_address(host)) for host in args.hosts]
    except ValueError as exc:
        print(f"Error: {exc}. Supply explicit IPv4 or IPv6 addresses only.", file=sys.stderr)
        return 2

    previous = load_inventory(args.inventory)
#Loads the old inventory from the chosen JSON file. If no usable previous inventory exists, load_inventory supplies an empty baseline.
    current = scan_hosts(hosts, args.ports, args.timeout)
#Scans the validated IP addresses using the selected ports and timeout. The results, including a timestamp, are stored in current.
    changes = compare_inventories(previous, current)
#Compares the old and current inventories. It identifies services that appeared or disappeared.
    try:
        save_inventory(args.inventory, current)
    except OSError as exc:
        print(f"Could not save inventory: {exc}", file=sys.stderr)
        return 1

    print(f"Scan completed at {current['scanned_at']} (TCP; {len(hosts)} host(s), {len(args.ports)} port(s)).")
    for host, result in current["hosts"].items(): #Loops through each scanned IP address and its result.
        ports = result["open_ports"] #Gets the list of ports that accepted a connection for that IP address.
        print(f"{host}: open TCP ports: {', '.join(map(str, ports)) if ports else 'none detected'}") 
#Prints the IP address and its open ports. If the list is empty, it prints "none detected".
    for label in ("new_services", "disappeared_services"): #Loops through the two types of changes found by the comparison function.
        print(f"{label.replace('_', ' ').title()}: {len(changes[label])}")
        for item in changes[label]:
            print(f"  {item['host']}:{item['port']}") #Prints each changed service as an IP address followed by its port.
    print(f"Inventory saved to {args.inventory}") #Tells the user where the latest inventory was saved.
    return 0 #meaning the program completed successfully.


if __name__ == "__main__":
    raise SystemExit(main())
