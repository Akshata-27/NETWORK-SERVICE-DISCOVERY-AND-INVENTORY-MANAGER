"""Small, bounded TCP connect scanner; uses only Python's socket library."""

from datetime import datetime, timezone
import ipaddress
import socket

# Intentionally small default set. Override with --ports when appropriate.
DEFAULT_PORTS = [22, 80, 443, 3306, 5432]


#This defines a function named scan_host. It takes an IP address (host), 
#a list of port numbers (ports), and how long to wait for each connection (timeout)
def scan_host(host: str, ports: list[int], timeout: float = 0.5) -> dict:
    """Try a TCP connection to each selected port and return successful ports."""

## This accepts IP addresses only, not hostnames or address ranges.
    address = str(ipaddress.ip_address(host))  # Reject names, CIDRs, and malformed input.
    open_ports = []
    for port in ports:

        #A valid port must be an integer from 1 to 65535. 
        #If it isn’t, Python raises an error and stops this function.
        if not isinstance(port, int) or not 1 <= port <= 65535:
            raise ValueError(f"invalid TCP port: {port!r}")

        
        family = socket.AF_INET6 if ":" in address else socket.AF_INET
        try:
            with socket.socket(family, socket.SOCK_STREAM) as client:
                client.settimeout(timeout)
                result = client.connect_ex((address, port))
                if result == 0:
                    open_ports.append(port) #If the connection succeeds, the port number is added to open_ports.
        except (OSError, TimeoutError):
            # Closed, unreachable, filtered, and unavailable ports are not reported open.
            continue
    return {"open_ports": open_ports} #The function returns a dictionary containing the ports that accepted a connection {80,443}


def scan_hosts(hosts: list[str], ports: list[int], timeout: float = 0.5) -> dict:
    """Scan each supplied address and produce a timestamped inventory snapshot."""
    results = {}
    for host in hosts:
        address = str(ipaddress.ip_address(host))
        if address in results:
            continue
        results[address] = scan_host(address, ports, timeout)
    return {
        "scanned_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "method": "TCP connect",
        "hosts": results,
    }
