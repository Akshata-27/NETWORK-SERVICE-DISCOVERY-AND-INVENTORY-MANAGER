"""Tests use loopback and an ephemeral local TCP server only."""

import json
import socket
import tempfile
import threading
import unittest
from pathlib import Path

from network_service_inventory.inventory import compare_inventories, load_inventory, save_inventory
from network_service_inventory.scanner import scan_host


class InventoryTests(unittest.TestCase):
    def test_detects_added_and_removed_services(self):
        previous = {"hosts": {"127.0.0.1": {"open_ports": [80, 443]}}}
        current = {"hosts": {"127.0.0.1": {"open_ports": [443, 8080]}}}
        changes = compare_inventories(previous, current)
        self.assertEqual(changes["new_services"], [{"host": "127.0.0.1", "port": 8080}])
        self.assertEqual(changes["disappeared_services"], [{"host": "127.0.0.1", "port": 80}])

    def test_json_round_trip(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "nested" / "inventory.json"
            data = {"scanned_at": "now", "hosts": {}}
            save_inventory(path, data)
            self.assertEqual(load_inventory(path), data)

    def test_missing_inventory_is_empty(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(load_inventory(Path(folder) / "missing.json"), {"hosts": {}})

    def test_scans_local_mock_server(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind(("127.0.0.1", 0))
        server.listen()
        port = server.getsockname()[1]
        thread = threading.Thread(target=server.accept, daemon=True)
        thread.start()
        try:
            self.assertEqual(scan_host("127.0.0.1", [port], timeout=1)["open_ports"], [port])
        finally:
            server.close()

    def test_rejects_hostname(self):
        with self.assertRaises(ValueError):
            scan_host("localhost", [80])


if __name__ == "__main__":
    unittest.main()
