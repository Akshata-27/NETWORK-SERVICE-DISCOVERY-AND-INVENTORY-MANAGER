"""Read, write, and compare JSON inventory snapshots."""

import json
from pathlib import Path


def load_inventory(path: Path) -> dict:
    """Load previous JSON data; missing or malformed files start a fresh baseline."""
    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file) 
#This reads JSON text from the open file and converts it into Python data, usually dictionaries and lists. The result is stored in data           
        if not isinstance(data, dict) or not isinstance(data.get("hosts"), dict):
            raise ValueError("inventory must contain a hosts object")
        return data
    except FileNotFoundError:
        return {"hosts": {}}
    except (json.JSONDecodeError, OSError, ValueError) as exc:
        print(f"Warning: previous inventory could not be read ({exc}); starting a new baseline.")
#This prints a warning. The f before the string lets Python insert the error details from exc
        return {"hosts": {}}


def save_inventory(path: Path, inventory: dict) -> None:
    """Write readable JSON, creating the parent directory when needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(inventory, file, indent=2) #indent=2 adds spacing so the JSON is easier for a person to read.
        file.write("\n")


def _service_set(inventory: dict) -> set[tuple[str, int]]:
    services = set()
    for host, details in inventory.get("hosts", {}).items():
        for port in details.get("open_ports", []):
#this loops through its open ports. If "open_ports" is missing, it uses an empty list.
            services.add((host, int(port)))
    return services #This returns the set of all unique host-and-port pairs.


def compare_inventories(previous: dict, current: dict) -> dict:
    """Return services newly present or absent between two snapshots."""
    old = _service_set(previous) #contains the services from the previous scan
    new = _service_set(current) #contains the services from the current scan
    return {
        "new_services": [dict(host=h, port=p) for h, p in sorted(new - old)],
        "disappeared_services": [dict(host=h, port=p) for h, p in sorted(old - new)],
    }
